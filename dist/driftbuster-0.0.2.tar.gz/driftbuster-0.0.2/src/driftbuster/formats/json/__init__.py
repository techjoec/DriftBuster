"""JSON format plugin package."""

from .plugin import JsonPlugin

__all__ = ["JsonPlugin"]
