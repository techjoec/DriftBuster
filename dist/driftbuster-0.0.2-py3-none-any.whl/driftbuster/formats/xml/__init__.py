"""XML format plugin implementations."""

from .plugin import XmlPlugin

__all__ = ["XmlPlugin"]
