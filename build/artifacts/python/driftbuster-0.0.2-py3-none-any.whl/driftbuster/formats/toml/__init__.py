"""TOML format plugin package."""

from .plugin import TomlPlugin

__all__ = ["TomlPlugin"]

