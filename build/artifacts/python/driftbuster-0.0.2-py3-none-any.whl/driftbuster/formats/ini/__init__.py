"""INI format plugin package."""

from .plugin import IniPlugin

__all__ = ["IniPlugin"]
