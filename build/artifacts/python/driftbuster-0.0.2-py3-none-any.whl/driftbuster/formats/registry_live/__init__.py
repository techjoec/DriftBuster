"""Registry live-scan definition format plugin."""

from .plugin import RegistryLivePlugin  # noqa: F401

