"""Conf DSL plugin package."""

from .plugin import ConfPlugin

__all__ = ["ConfPlugin"]

