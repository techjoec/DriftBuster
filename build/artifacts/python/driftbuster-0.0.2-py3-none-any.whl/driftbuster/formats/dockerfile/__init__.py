"""Dockerfile format plugin package."""

from .plugin import DockerfilePlugin

__all__ = ["DockerfilePlugin"]

