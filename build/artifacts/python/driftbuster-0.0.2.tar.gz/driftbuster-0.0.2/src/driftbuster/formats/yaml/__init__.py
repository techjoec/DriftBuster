"""YAML format plugin package."""

from .plugin import YamlPlugin

__all__ = ["YamlPlugin"]

