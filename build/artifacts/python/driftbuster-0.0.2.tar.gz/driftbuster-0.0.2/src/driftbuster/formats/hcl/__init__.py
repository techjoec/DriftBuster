"""HCL format plugin package."""

from .plugin import HclPlugin

__all__ = ["HclPlugin"]

