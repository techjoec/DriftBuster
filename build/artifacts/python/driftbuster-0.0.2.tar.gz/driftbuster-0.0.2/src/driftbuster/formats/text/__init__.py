"""Generic directive-oriented text config plugin package."""

from .plugin import TextPlugin

__all__ = ["TextPlugin"]

